import 'package:flutter/material.dart';

class NeumorphicContainer extends StatelessWidget {
  final Widget child;
  final bool isPressed;

  const NeumorphicContainer({
    super.key,
    required this.child,
    this.isPressed = false,
  });

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    final backgroundColor = Theme.of(context).scaffoldBackgroundColor;
    
    // Sombras para modo claro
    final lightShadow = const BoxShadow(
      color: Colors.white,
      offset: Offset(-5, -5),
      blurRadius: 15,
    );
    final darkShadow = BoxShadow(
      color: Colors.grey.shade500,
      offset: const Offset(5, 5),
      blurRadius: 15,
    );
    
    // Sombras para modo oscuro
    final darkThemeDarkShadow = const BoxShadow(
      color: Color(0xFF1F2227),
      offset: Offset(5, 5),
      blurRadius: 15,
    );
    final darkThemeLightShadow = const BoxShadow(
      color: Color(0xFF3D434D),
      offset: Offset(-5, -5),
      blurRadius: 15,
    );

    return AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(15),
        gradient: isPressed
            ? LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  isDarkMode ? Color(0xFF282C32) : Colors.grey.shade400,
                  isDarkMode ? Color(0xFF343840) : Colors.grey.shade200,
                ],
              )
            : null,
        boxShadow: isPressed
            ? []
            : [
                isDarkMode ? darkThemeDarkShadow : darkShadow,
                isDarkMode ? darkThemeLightShadow : lightShadow,
              ],
      ),
      child: child,
    );
  }
}