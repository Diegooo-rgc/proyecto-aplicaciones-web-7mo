class UserProfile {
  final String name;
  final String lastName;
  final String password;

  UserProfile({required this.name, required this.lastName, required this.password});
}
