import '../models/user_profile.dart';

class DataService {
  static final List<UserProfile> users = [];
}
