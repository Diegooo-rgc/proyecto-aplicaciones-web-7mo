import 'package:flutter/material.dart';
import '../main.dart';
import '../widgets/neumorphic_container.dart';

class SettingsView extends StatelessWidget {
  const SettingsView({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = NeumorphicPortfolioApp.of(context);
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        children: [
          NeumorphicContainer(
            child: SwitchListTile(
              title: Text('Modo Oscuro', style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold)),
              value: appState.isDarkMode,
              onChanged: (value) {
                appState.toggleTheme();
              },
              secondary: Icon(appState.isDarkMode ? Icons.dark_mode : Icons.light_mode, color: theme.iconTheme.color),
            ),
          ),
          const SizedBox(height: 20),
          NeumorphicContainer(
            child: ListTile(
              leading: Icon(Icons.info_outline, color: theme.iconTheme.color),
              title: Text('Acerca de', style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold)),
              onTap: () {
                showAboutDialog(
                  context: context,
                  applicationName: 'Neumorphic Portfolio',
                  applicationVersion: '1.0.0',
                  children: [
                    const Text('Este es un proyecto desarrollado por Diego Alberto Rodriguez Garcia.'),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}