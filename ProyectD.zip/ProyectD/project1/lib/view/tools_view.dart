import 'package:flutter/material.dart';
import '../widgets/neumorphic_list_tile.dart';
import '../modules/tools/tool_note.dart';
import '../modules/tools/tool_bmi.dart';
import '../modules/tools/tool_gallery.dart';
import '../modules/tools/tool_game.dart';

class ToolsView extends StatelessWidget {
  const ToolsView({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        NeumorphicListTile(
          title: 'Notas Rápidas',
          subtitle: 'Un bloc de notas simple.',
          icon: Icons.note_add,
          onTap: () => _navigateToPage(context, const ToolNotes()),
        ),
        NeumorphicListTile(
          title: 'Calculadora de IMC',
          subtitle: 'Calcula tu índice de masa corporal.',
          icon: Icons.monitor_weight,
          onTap: () => _navigateToPage(context, const ToolBmi()),
        ),
        NeumorphicListTile(
          title: 'Galería Local',
          subtitle: 'Visor de imágenes desde assets.',
          icon: Icons.photo_library,
          onTap: () => _navigateToPage(context, const ToolGallery()),
        ),
        NeumorphicListTile(
          title: 'Juego: Par o Impar',
          subtitle: 'Juego de azar contra la CPU.',
          icon: Icons.casino,
          onTap: () => _navigateToPage(context, const ToolGame()),
        ),
      ],
    );
  }

  void _navigateToPage(BuildContext context, Widget page) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => page),
    );
  }
}