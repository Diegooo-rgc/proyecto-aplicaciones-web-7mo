import 'package:flutter/material.dart';
import 'home_view.dart';
import 'demos_view.dart';
import 'tools_view.dart';
import 'settings_view.dart';
import '../widgets/neumorphic_container.dart';

class AppContainer extends StatelessWidget {
  const AppContainer({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDarkMode = theme.brightness == Brightness.dark;

    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: theme.scaffoldBackgroundColor,
          elevation: 0,
          title: Text('Mi Portafolio', style: theme.textTheme.titleLarge),
          centerTitle: true,
          bottom: TabBar(
            indicator: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: isDarkMode ? Colors.grey.shade800 : Colors.white,
            ),
             indicatorPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            labelColor: isDarkMode ? Colors.white : Colors.black,
            unselectedLabelColor: isDarkMode ? Colors.white54 : Colors.grey.shade600,
            tabs: const [
              Tab(icon: Icon(Icons.home_rounded), text: 'Inicio'),
              Tab(icon: Icon(Icons.science_outlined), text: 'Demos'),
              Tab(icon: Icon(Icons.construction_rounded), text: 'Herramientas'),
              Tab(icon: Icon(Icons.settings_rounded), text: 'Ajustes'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            HomeView(),
            DemosView(),
            ToolsView(),
            SettingsView(),
          ],
        ),
      ),
    );
  }
}