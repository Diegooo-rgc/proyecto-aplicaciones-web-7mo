import 'package:flutter/material.dart';
import '../widgets/neumorphic_list_tile.dart';
import '../modules/demo_1_greetings.dart';
import '../modules/demo_2_buttons.dart';
import '../modules/demo_3_form.dart';
import '../modules/demo_4_list.dart';
import '../modules/demo_5_rps.dart';

class DemosView extends StatelessWidget {
  const DemosView({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        NeumorphicListTile(
          title: 'Demo 1: Saludos x10',
          subtitle: 'Un ListView simple.',
          icon: Icons.format_list_numbered,
          onTap: () => _navigateToPage(context, const Demo1Greetings()),
        ),
        NeumorphicListTile(
          title: 'Demo 2: Saludos Interactivos',
          subtitle: 'Manejo de estado con botones.',
          icon: Icons.touch_app,
          onTap: () => _navigateToPage(context, const Demo2Buttons()),
        ),
        NeumorphicListTile(
          title: 'Demo 3: Formulario de Registro',
          subtitle: 'Validación de entradas.',
          icon: Icons.edit,
          onTap: () => _navigateToPage(context, const Demo3Form()),
        ),
        NeumorphicListTile(
          title: 'Demo 4: Lista de Registros',
          subtitle: 'Visualización de datos en memoria.',
          icon: Icons.people,
          onTap: () => _navigateToPage(context, const Demo4List()),
        ),
        NeumorphicListTile(
          title: 'Demo 5: Piedra, Papel o Tijera',
          subtitle: 'Un juego simple contra la CPU.',
          icon: Icons.sports_esports,
          onTap: () => _navigateToPage(context, const Demo5RPS()),
        ),
      ],
    );
  }

  void _navigateToPage(BuildContext context, Widget page) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => page),
    );
  }
}